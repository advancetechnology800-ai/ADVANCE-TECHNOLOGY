এডভান্স টেকনোলজি ওয়েবসাইট

ফাইল: index.html

ফ্রি প্রকাশ করতে:
1. github.com এ অ্যাকাউন্ট খুলুন/লগইন করুন।
2. New repository তৈরি করুন, যেমন: advance-technology
3. index.html আপলোড করুন।
4. Settings → Pages → Deploy from branch → main → /root নির্বাচন করুন।
5. Save চাপুন। কিছুক্ষণ পর GitHub একটি ফ্রি ওয়েবসাইট লিংক দেবে।

WhatsApp: 01760189431
Location: Habiganj, Bangladesh
